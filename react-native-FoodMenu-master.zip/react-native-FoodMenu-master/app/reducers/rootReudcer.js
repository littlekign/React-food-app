
import { combineReducers } from 'redux';
import FrontPage from './frontPageReducer';


export default rootReducer = combineReducers({
    FrontPage,
})
